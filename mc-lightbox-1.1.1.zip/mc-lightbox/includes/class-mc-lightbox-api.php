<?php
if (!defined('ABSPATH')) {
    exit;
}

class MC_Lightbox_API {

    public function __construct() {
        add_action('rest_api_init', [$this, 'register_routes']);
    }

    public function register_routes() {
        register_rest_route('mc-lightbox/v1', '/gallery/(?P<folder>[a-zA-Z0-9_%\-]+)', [
            'methods'  => 'GET',
            'callback' => [$this, 'get_gallery_images'],
            'permission_callback' => '__return_true',
            'args' => [
                'folder' => [
                    'sanitize_callback' => 'sanitize_title',
                ],
            ],
        ]);
    }

    public function get_gallery_images($request) {
        $folder = $request->get_param('folder');

        if (!is_string($folder) || '' === $folder) {
            return new WP_Error('no_folder', 'No folder specified', ['status' => 400]);
        }

        $base_dir   = MC_LB_UPLOAD_DIR;
        $target_dir = realpath($base_dir . $folder);
        $real_base  = realpath($base_dir);

        if ($real_base === false || false === $target_dir || strpos($target_dir, $real_base . DIRECTORY_SEPARATOR) !== 0 || !is_dir($target_dir)) {
            return new WP_Error('invalid_folder', 'Invalid or non-existent folder', ['status' => 404]);
        }

        $files = MC_Lightbox_Admin::get_media_files($folder);
        if (!$files) {
            return rest_ensure_response([]);
        }

        $alt_meta      = MC_Lightbox_Admin::read_metadata($folder);
        $video_ext_arr = array_map('strtolower', array_map('trim', explode(',', MC_LB_VIDEO_EXTENSIONS)));

        $media = array_map(function ($path) use ($folder, $video_ext_arr, $alt_meta) {
            $filename = basename($path);
            $ext      = strtolower(pathinfo($filename, PATHINFO_EXTENSION));
            $type     = in_array($ext, $video_ext_arr, true) ? 'video' : 'image';
            $alt      = (isset($alt_meta[$filename]) && is_string($alt_meta[$filename])) ? $alt_meta[$filename] : '';

            return [
                'url'      => MC_Lightbox_Admin::get_media_url($folder, $filename),
                'type'     => $type,
                'filename' => $filename,
                'alt'      => $alt,
            ];
        }, $files);

        return rest_ensure_response($media);
    }
}

new MC_Lightbox_API();

