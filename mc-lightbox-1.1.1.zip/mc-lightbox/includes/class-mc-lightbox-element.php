<?php
if (!defined('ABSPATH')) {
    exit;
}

class MC_Lightbox_Element {

    public function __construct() {
        add_action('init', [$this, 'register_mosaik_element']);
    }

    private function get_available_folders() {
        $options = ['' => '-- Select folder --'];

        if (class_exists('MC_Lightbox_Admin')) {
            foreach (MC_Lightbox_Admin::get_folders() as $folder_name) {
                $options[$folder_name] = $folder_name;
            }
        }

        return $options;
    }

    public function register_mosaik_element() {
        if (!function_exists('mosaik_register_element') && !class_exists('Mosaik_Builder')) {
            return;
        }

        $folders = $this->get_available_folders();

        $element_args = [
            'name'        => 'mc_lightbox',
            'title'       => 'MC-Lightbox',
            'icon'        => 'dashicons-format-gallery',
            'category'    => 'media',
            'controls'    => [
                'trigger_image' => [
                    'type'        => 'image',
                    'label'       => 'Trigger image (Cover)',
                    'description' => 'Select the image that appears as a preview on the page.',
                    'default'     => '',
                ],
                'gallery_folder' => [
                    'type'        => 'select',
                    'label'       => 'Gallery folder',
                    'description' => 'Select a folder from the MC-Lightbox management.',
                    'options'     => $folders,
                    'default'     => '',
                ],
                'image_alt' => [
                    'type'        => 'text',
                    'label'       => 'Alt text (SEO)',
                    'default'     => 'Gallery preview',
                ]
            ],
            'render_callback' => [$this, 'render_element_html']
        ];

        if (function_exists('mosaik_register_element')) {
            mosaik_register_element($element_args);
        }
    }

    public function render_element_html($attributes) {
        $image_id = !empty($attributes['trigger_image']) ? $attributes['trigger_image'] : '';
        $folder   = isset($attributes['gallery_folder']) && is_string($attributes['gallery_folder']) && '' !== $attributes['gallery_folder']
            ? sanitize_title($attributes['gallery_folder'])
            : '';
        $alt      = isset($attributes['image_alt']) && is_string($attributes['image_alt']) ? $attributes['image_alt'] : '';

        if ('' === $folder) {
            return '<p style="padding:15px; background:#fff3cd; color:#856404; border:1px solid #ffeeba;">Please select a gallery folder in the MC-Lightbox element.</p>';
        }

        $img_src    = '';
        $has_custom = false;
        if (is_numeric($image_id)) {
            $img_data = wp_get_attachment_image_src($image_id, 'full');
            if ($img_data) {
                $img_src    = $img_data[0];
                $has_custom = true;
            }
        } elseif (is_string($image_id)) {
            $img_src    = esc_url($image_id);
            $has_custom = '' !== $img_src;
        }

        $alt_from_meta = '';
        if (!$has_custom) {
            $images = class_exists('MC_Lightbox_Admin') ? MC_Lightbox_Admin::get_media_files($folder, true) : [];

            if (!empty($images)) {
                $first_file    = basename($images[0]);
                $img_src       = MC_Lightbox_Admin::get_media_url($folder, $first_file);
                $alt_from_meta = MC_Lightbox_Admin::get_alt_text($folder, $first_file);
            }
        }

        // An explicitly configured cover image and alt text must win.
        if (!$has_custom && '' !== $alt_from_meta) {
            $alt = $alt_from_meta;
        } elseif ($has_custom && '' === $alt && is_numeric($image_id)) {
            $attachment_alt = get_post_meta((int) $image_id, '_wp_attachment_image_alt', true);
            if (is_string($attachment_alt)) {
                $alt = $attachment_alt;
            }
        }

        if ('' === $img_src) {
            $has_media = class_exists('MC_Lightbox_Admin') && !empty(MC_Lightbox_Admin::get_media_files($folder));
            $message   = $has_media
                ? __('No preview image found in this folder.', 'mc-lightbox')
                : __('No preview image found and the folder is empty.', 'mc-lightbox');

            return '<p style="padding:15px; background:#f8d7da; color:#721c24; border:1px solid #f5c6cb;">' . esc_html($message) . '</p>';
        }

        $builder_class = 'mc-galerie-' . $folder;

        ob_start();
        ?>
        <div class="<?php echo esc_attr($builder_class); ?> mc-lightbox-trigger-wrap" data-mc-folder="<?php echo esc_attr($folder); ?>" style="cursor: pointer; display: inline-block; max-width: 100%;">
            <a href="#" style="display: block; text-decoration: none;">
                <img src="<?php echo esc_url($img_src); ?>" alt="<?php echo esc_attr($alt); ?>" style="max-width: 100%; height: auto; display: block;">
            </a>
        </div>
        <?php
        return ob_get_clean();
    }
}

new MC_Lightbox_Element();