<?php
/**
 * Plugin Name: MC-Lightbox
 * Plugin URI: https://wpplugin.dpbase.de/
 * Description: Lightweight, folder-based lightbox for the Mosaic Builder community.
 * Version: 1.1.1
 * Requires at least: 6.5
 * Requires PHP: 8.2
 * Author: Patryk P.
 * Author URI: https://wpplugin.dpbase.de/
 * License: GPLv2 or later
 * License URI: https://www.gnu.org/licenses/old-licenses/gpl-2.0.html
 * Text Domain: mc-lightbox
 * Domain Path: /languages
 */

if (!defined('ABSPATH')) {
    exit;
}

define('MC_LB_PATH', plugin_dir_path(__FILE__));
define('MC_LB_URL', plugin_dir_url(__FILE__));
define('MC_LB_UPLOAD_DIR', wp_upload_dir()['basedir'] . '/mc-galleries/');
define('MC_LB_UPLOAD_URL', wp_upload_dir()['baseurl'] . '/mc-galleries/');

if (!defined('MC_LB_VERSION')) {
    define('MC_LB_VERSION', '1.1.1');
}

if (!defined('MC_LB_IMAGE_EXTENSIONS')) {
    define('MC_LB_IMAGE_EXTENSIONS', 'jpg,jpeg,png,webp,gif');
}
if (!defined('MC_LB_VIDEO_EXTENSIONS')) {
    define('MC_LB_VIDEO_EXTENSIONS', 'mp4');
}

require_once MC_LB_PATH . 'includes/class-mc-lightbox-api.php';
require_once MC_LB_PATH . 'includes/class-mc-lightbox-element.php';

class MC_Lightbox_Admin {

    public function __construct() {
        add_action('init', [$this, 'load_textdomain']);
        add_action('admin_menu', [$this, 'add_admin_menu']);
        add_action('admin_init', [$this, 'handle_actions']);
        add_action('wp_enqueue_scripts', [$this, 'enqueue_frontend_assets']);
    }

    public function load_textdomain() {
        load_plugin_textdomain('mc-lightbox', false, dirname(plugin_basename(__FILE__)) . '/languages');
    }


    public function enqueue_frontend_assets() {
        wp_enqueue_style('mc-lightbox-css', MC_LB_URL . 'assets/css/mc-lightbox-frontend.css', [], MC_LB_VERSION);
        wp_enqueue_script('mc-lightbox-js', MC_LB_URL . 'assets/js/mc-lightbox-frontend.js', [], MC_LB_VERSION, true);

        wp_localize_script('mc-lightbox-js', 'mcLightboxData', [
            'restUrl' => esc_url_raw(rest_url('mc-lightbox/v1/gallery/')),
            'i18n'    => [
                'gallery'  => __('Gallery', 'mc-lightbox'),
                'close'    => __('Close', 'mc-lightbox'),
                'previous' => __('Previous item', 'mc-lightbox'),
                'next'     => __('Next item', 'mc-lightbox'),
            ],
        ]);
    }

    public function add_admin_menu() {
        add_menu_page(
            'MC-Lightbox',
            'MC-Lightbox',
            'manage_options',
            'mc-lightbox',
            [$this, 'render_admin_page'],
            'dashicons-format-gallery',
            30
        );
    }

    private function ensure_base_dir() {
        if (!file_exists(MC_LB_UPLOAD_DIR)) {
            wp_mkdir_p(MC_LB_UPLOAD_DIR);
        }
    }

    public static function get_metadata_path($folder_name) {
        $folder_name = sanitize_title($folder_name);
        $folder_dir  = MC_LB_UPLOAD_DIR . $folder_name;
        if ('' === $folder_name || !is_dir($folder_dir)) {
            return '';
        }
        return $folder_dir . '/metadata.json';
    }

    public static function read_metadata($folder_name) {
        $path = self::get_metadata_path($folder_name);
        if ('' === $path || !is_file($path) || !is_readable($path)) {
            return [];
        }
        $raw = file_get_contents($path);
        if ($raw === false || $raw === '') {
            return [];
        }
        $data = json_decode($raw, true);
        return is_array($data) ? $data : [];
    }

    public static function get_alt_text($folder_name, $filename) {
        $meta = self::read_metadata($folder_name);
        $filename = basename($filename);
        if (isset($meta[$filename]) && is_string($meta[$filename])) {
            return $meta[$filename];
        }
        return '';
    }

    public static function is_video($filename) {
        $ext = strtolower(pathinfo($filename, PATHINFO_EXTENSION));
        $video_exts = array_map('strtolower', array_map('trim', explode(',', MC_LB_VIDEO_EXTENSIONS)));
        return in_array($ext, $video_exts, true);
    }

    public static function get_folders() {
        if (!is_dir(MC_LB_UPLOAD_DIR) || !is_readable(MC_LB_UPLOAD_DIR)) {
            return [];
        }

        $entries = scandir(MC_LB_UPLOAD_DIR);
        if (!is_array($entries)) {
            return [];
        }

        $folders = [];
        foreach ($entries as $entry) {
            if ('.' === $entry || '..' === $entry || strpos($entry, '.') === 0) {
                continue;
            }
            if (is_dir(MC_LB_UPLOAD_DIR . $entry)) {
                $folders[] = $entry;
            }
        }

        natsort($folders);
        return array_values($folders);
    }

    /**
     * Returns media files in a gallery folder, case-insensitively by extension.
     * This avoids GLOB_BRACE portability issues and uppercase extensions on Linux.
     */
    public static function get_media_files($folder_name, $images_only = false) {
        $folder_name = sanitize_title($folder_name);
        if ('' === $folder_name) {
            return [];
        }

        $dir = MC_LB_UPLOAD_DIR . $folder_name;
        if (!is_dir($dir) || !is_readable($dir)) {
            return [];
        }

        $extensions = $images_only
            ? MC_LB_IMAGE_EXTENSIONS
            : MC_LB_IMAGE_EXTENSIONS . ',' . MC_LB_VIDEO_EXTENSIONS;
        $allowed = array_map('strtolower', array_map('trim', explode(',', $extensions)));

        $entries = scandir($dir);
        if (!is_array($entries)) {
            return [];
        }

        $files = [];
        foreach ($entries as $entry) {
            if ('.' === $entry || '..' === $entry || strpos($entry, '.') === 0) {
                continue;
            }

            $path = $dir . DIRECTORY_SEPARATOR . $entry;
            if (!is_file($path)) {
                continue;
            }

            $ext = strtolower(pathinfo($entry, PATHINFO_EXTENSION));
            if (in_array($ext, $allowed, true)) {
                $files[] = $path;
            }
        }

        natsort($files);
        return array_values($files);
    }

    public static function get_media_url($folder_name, $filename) {
        return MC_LB_UPLOAD_URL . rawurlencode(sanitize_title($folder_name)) . '/' . rawurlencode(basename($filename));
    }

    private function redirect_admin($args = []) {
        $args = array_merge(['page' => 'mc-lightbox'], $args);
        wp_safe_redirect(add_query_arg($args, admin_url('admin.php')));
        exit;
    }

    private function nonce_field($action, $id) {
        return sprintf(
            '<input type="hidden" id="%s" name="mc_nonce" value="%s">',
            esc_attr($id),
            esc_attr(wp_create_nonce($action))
        );
    }

    private function get_string($value) {
        return is_string($value) ? wp_unslash($value) : '';
    }

    private function save_metadata($folder_name, $alt_texts) {
        $path = self::get_metadata_path($folder_name);
        if ('' === $path) {
            return false;
        }
        $clean = [];
        foreach ($alt_texts as $filename => $alt) {
            $filename = sanitize_file_name(basename($filename));
            if ($filename === '') {
                continue;
            }
            $clean[$filename] = sanitize_text_field($alt);
        }
        $json = wp_json_encode($clean, JSON_PRETTY_PRINT | JSON_UNESCAPED_UNICODE | JSON_UNESCAPED_SLASHES);
        if ($json === false) {
            return false;
        }

        // Write atomically so concurrent frontend requests never read partial JSON.
        $tmp_path = $path . '.tmp-' . wp_generate_password(8, false, false);
        if (file_put_contents($tmp_path, $json, LOCK_EX) === false) {
            @unlink($tmp_path);
            return false;
        }

        if (@rename($tmp_path, $path)) {
            return true;
        }

        // Windows cannot always overwrite an existing file with rename().
        @unlink($path);
        if (@rename($tmp_path, $path)) {
            return true;
        }

        @unlink($tmp_path);
        return false;
    }

    private function delete_folder_recursive($dir) {
        if (is_link($dir)) {
            return unlink($dir);
        }
        if (!file_exists($dir)) {
            return true;
        }
        if (!is_dir($dir)) {
            return unlink($dir);
        }
        if (!is_readable($dir)) {
            return false;
        }

        $items = scandir($dir);
        if (!is_array($items)) {
            return false;
        }

        foreach ($items as $item) {
            if ('.' === $item || '..' === $item) {
                continue;
            }
            if (!$this->delete_folder_recursive($dir . DIRECTORY_SEPARATOR . $item)) {
                return false;
            }
        }
        return rmdir($dir);
    }

    public function handle_actions() {
        if (!current_user_can('manage_options')) {
            return;
        }

        $this->ensure_base_dir();

        if (isset($_POST['mc_create_folder']) && check_admin_referer('mc_create_folder_action', 'mc_nonce')) {
            $folder_name = sanitize_title($this->get_string($_POST['mc_folder_name'] ?? ''));

            if ('' === $folder_name) {
                $this->redirect_admin(['mc_notice' => 'invalid_folder']);
            }

            $target_dir = MC_LB_UPLOAD_DIR . $folder_name;
            if (is_dir($target_dir)) {
                $this->redirect_admin([
                    'folder'    => rawurlencode($folder_name),
                    'mc_notice' => 'folder_exists',
                ]);
            }

            if (wp_mkdir_p($target_dir)) {
                $this->redirect_admin([
                    'folder'    => rawurlencode($folder_name),
                    'mc_notice' => 'folder_created',
                ]);
            }

            $this->redirect_admin(['mc_notice' => 'folder_failed']);
        }

        if (isset($_POST['mc_upload_images']) && check_admin_referer('mc_upload_action', 'mc_nonce')) {
            $folder_name = sanitize_title($this->get_string($_POST['mc_target_folder'] ?? ''));

            if ('' === $folder_name || !is_dir(MC_LB_UPLOAD_DIR . $folder_name)) {
                $this->redirect_admin(['mc_notice' => 'invalid_folder']);
            }

            $target_dir = MC_LB_UPLOAD_DIR . $folder_name . '/';
            $image_exts = array_map('strtolower', array_map('trim', explode(',', MC_LB_IMAGE_EXTENSIONS)));
            $video_exts = array_map('strtolower', array_map('trim', explode(',', MC_LB_VIDEO_EXTENSIONS)));
            $allowed    = array_merge($image_exts, $video_exts);
            $uploaded   = 0;
            $failed     = 0;

            if (!empty($_FILES['mc_images']['name']) && is_array($_FILES['mc_images']['name'])) {
                $files = $_FILES['mc_images'];

                foreach ($files['name'] as $key => $name) {
                    $upload_error = isset($files['error'][$key]) ? (int) $files['error'][$key] : UPLOAD_ERR_NO_FILE;

                    if (UPLOAD_ERR_NO_FILE === $upload_error) {
                        continue;
                    }
                    if (UPLOAD_ERR_OK !== $upload_error || !is_string($name)) {
                        ++$failed;
                        continue;
                    }

                    $tmp_name = isset($files['tmp_name'][$key]) && is_string($files['tmp_name'][$key]) ? $files['tmp_name'][$key] : '';
                    if ('' === $tmp_name || !is_uploaded_file($tmp_name)) {
                        ++$failed;
                        continue;
                    }

                    $check = wp_check_filetype_and_ext($tmp_name, $name);
                    $ext   = isset($check['ext']) ? strtolower((string) $check['ext']) : '';

                    if (empty($check['type']) || !in_array($ext, $allowed, true)) {
                        ++$failed;
                        continue;
                    }

                    if (in_array($ext, $video_exts, true) && strpos((string) $check['type'], 'video/') !== 0) {
                        ++$failed;
                        continue;
                    }

                    $filename = sanitize_file_name($name);
                    if ('' === $filename) {
                        ++$failed;
                        continue;
                    }

                    // Keep only the last extension and normalize it to lowercase.
                    $pathinfo  = pathinfo($filename);
                    $extension = isset($pathinfo['extension']) ? strtolower($pathinfo['extension']) : '';
                    if ('' !== $extension) {
                        $filename = $pathinfo['filename'] . '.' . $extension;
                    }

                    $filename = wp_unique_filename($target_dir, $filename);
                    if (false === $filename) {
                        ++$failed;
                        continue;
                    }

                    if (move_uploaded_file($tmp_name, $target_dir . $filename)) {
                        ++$uploaded;
                    } else {
                        ++$failed;
                    }
                }
            }

            $notice = 'upload_empty';
            if ($uploaded > 0) {
                $notice = 'uploaded';
            } elseif ($failed > 0) {
                $notice = 'upload_failed';
            }

            $args = [
                'folder'    => rawurlencode($folder_name),
                'mc_notice' => $notice,
            ];
            if ($uploaded > 0) {
                $args['mc_count'] = $uploaded;
            }

            $this->redirect_admin($args);
        }

        if (isset($_POST['mc_save_alt_texts']) && check_admin_referer('mc_save_alt_action', 'mc_nonce')) {
            $folder_name = sanitize_title($this->get_string($_POST['mc_alt_folder'] ?? ''));

            if ('' === $folder_name || !is_dir(MC_LB_UPLOAD_DIR . $folder_name)) {
                $this->redirect_admin(['mc_notice' => 'invalid_folder']);
            }

            $alt_input = (isset($_POST['mc_alt']) && is_array($_POST['mc_alt'])) ? wp_unslash($_POST['mc_alt']) : [];
            $saved     = $this->save_metadata($folder_name, $alt_input);

            $this->redirect_admin([
                'folder'    => rawurlencode($folder_name),
                'mc_notice' => $saved ? 'alt_saved' : 'save_failed',
            ]);
        }

        if (isset($_POST['mc_delete_media'], $_POST['mc_delete_file'], $_POST['mc_delete_folder'])
            && check_admin_referer('mc_delete_media_action', 'mc_nonce')) {
            $folder_name = sanitize_title($this->get_string($_POST['mc_delete_folder']));
            $file_name   = sanitize_file_name(basename($this->get_string($_POST['mc_delete_file'])));
            $deleted     = false;

            if ('' !== $folder_name && '' !== $file_name) {
                $real_base   = realpath(MC_LB_UPLOAD_DIR);
                $folder_dir  = realpath(MC_LB_UPLOAD_DIR . $folder_name);
                $target_file = ($folder_dir !== false) ? realpath($folder_dir . DIRECTORY_SEPARATOR . $file_name) : false;

                if ($real_base && $folder_dir && $target_file
                    && strpos($folder_dir, $real_base . DIRECTORY_SEPARATOR) === 0
                    && strpos($target_file, $folder_dir . DIRECTORY_SEPARATOR) === 0
                    && is_file($target_file)) {
                    $deleted = unlink($target_file);

                    $meta = self::read_metadata($folder_name);
                    if (isset($meta[$file_name])) {
                        unset($meta[$file_name]);
                        $this->save_metadata($folder_name, $meta);
                    }
                }
            }

            $args = ['mc_notice' => $deleted ? 'media_deleted' : 'delete_failed'];
            if ('' !== $folder_name) {
                $args['folder'] = rawurlencode($folder_name);
            }
            $this->redirect_admin($args);
        }

        if (isset($_POST['mc_delete_folder'], $_POST['mc_delete_folder_name'])
            && check_admin_referer('mc_delete_folder_action', 'mc_nonce')) {
            $folder_to_delete = sanitize_title($this->get_string($_POST['mc_delete_folder_name']));
            $deleted          = false;

            if ('' !== $folder_to_delete) {
                $target_dir = realpath(MC_LB_UPLOAD_DIR . $folder_to_delete);
                $real_base  = realpath(MC_LB_UPLOAD_DIR);

                if ($real_base && $target_dir && strpos($target_dir, $real_base . DIRECTORY_SEPARATOR) === 0) {
                    $deleted = $this->delete_folder_recursive($target_dir);
                }
            }

            $this->redirect_admin(['mc_notice' => $deleted ? 'folder_deleted' : 'delete_failed']);
        }
    }

    private function render_admin_notices() {
        $notice = sanitize_key($this->get_string($_GET['mc_notice'] ?? ''));
        if ('' === $notice) {
            return;
        }

        $count = absint($this->get_string($_GET['mc_count'] ?? ''));

        switch ($notice) {
            case 'folder_created':
                $message = __('Gallery folder created.', 'mc-lightbox');
                break;
            case 'folder_exists':
                $message = __('This folder already exists.', 'mc-lightbox');
                break;
            case 'folder_failed':
                $message = __('The folder could not be created.', 'mc-lightbox');
                break;
            case 'invalid_folder':
                $message = __('Invalid folder.', 'mc-lightbox');
                break;
            case 'uploaded':
                $message = $count > 0
                    ? sprintf(_n('%s file uploaded.', '%s files uploaded.', $count, 'mc-lightbox'), number_format_i18n($count))
                    : __('Files uploaded.', 'mc-lightbox');
                break;
            case 'upload_failed':
                $message = __('No files could be uploaded. Please check the file type and the server limits.', 'mc-lightbox');
                break;
            case 'upload_empty':
                $message = __('No files were selected.', 'mc-lightbox');
                break;
            case 'alt_saved':
                $message = __('Alt texts saved.', 'mc-lightbox');
                break;
            case 'save_failed':
                $message = __('Alt texts could not be saved.', 'mc-lightbox');
                break;
            case 'media_deleted':
                $message = __('File deleted.', 'mc-lightbox');
                break;
            case 'folder_deleted':
                $message = __('Folder deleted.', 'mc-lightbox');
                break;
            case 'delete_failed':
                $message = __('The item could not be deleted.', 'mc-lightbox');
                break;
            default:
                return;
        }

        $error_notices = ['folder_failed', 'invalid_folder', 'upload_failed', 'upload_empty', 'save_failed', 'delete_failed'];
        $class         = in_array($notice, $error_notices, true) ? 'notice-error' : 'notice-success';

        printf(
            '<div class="notice %s is-dismissible"><p>%s</p></div>',
            esc_attr($class),
            esc_html($message)
        );
    }

    public function render_admin_page() {
        if (!current_user_can('manage_options')) {
            wp_die(esc_html__('You do not have sufficient permissions to access this page.', 'mc-lightbox'));
        }

        $this->ensure_base_dir();
        $active_folder = sanitize_title($this->get_string($_GET['folder'] ?? ''));
        $folders       = self::get_folders();
        ?>
        <div class="wrap">
            <h1><?php echo esc_html__('MC-Lightbox', 'mc-lightbox'); ?></h1>
            <?php $this->render_admin_notices(); ?>
            <style>
                .mc-lb-folders-table td,
                .mc-lb-folders-table th {
                    vertical-align: middle;
                }
                .mc-lb-folders-table td .button,
                .mc-lb-folders-table td code {
                    vertical-align: middle;
                }
                .mc-lb-cell-actions {
                    white-space: nowrap;
                }
                .mc-lb-cell-actions form {
                    display: inline;
                    margin: 0;
                }
                .mc-lb-delete-button {
                    margin-left: 10px;
                    color: #b32d2e;
                    text-decoration: none;
                }
                .mc-lb-upload-row {
                    display: flex;
                    align-items: stretch;
                    gap: 10px;
                    flex-wrap: wrap;
                }
                .mc-lb-upload-row input[type="file"] {
                    display: flex;
                    align-items: center;
                    height: 40px;
                    margin: 0;
                    padding: 0 8px 0 0;
                    border: 1px solid #8c8f94;
                    border-radius: 3px;
                    background: #fff;
                    box-sizing: border-box;
                    font-size: 13px;
                    line-height: 1;
                }
                .mc-lb-upload-row input[type="file"]::file-selector-button {
                    height: 100%;
                    margin: 0 8px 0 0;
                    padding: 0 12px;
                    border: none;
                    border-right: 1px solid #8c8f94;
                    border-radius: 0;
                    background: #f6f7f7;
                    color: #2271b1;
                    cursor: pointer;
                    font-size: 13px;
                    line-height: 1;
                    font-family: inherit;
                    box-sizing: border-box;
                }
                .mc-lb-upload-row .button {
                    height: 40px;
                    display: inline-flex;
                    align-items: center;
                }
                .mc-lb-media-item video {
                    width: 100%;
                    height: 100%;
                    object-fit: cover;
                    display: block;
                }
                .mc-lb-video-badge {
                    position: absolute;
                    top: 6px;
                    right: 6px;
                    background: rgba(0,0,0,0.7);
                    color: #fff;
                    font-size: 11px;
                    padding: 2px 6px;
                    border-radius: 3px;
                    pointer-events: none;
                }
                .mc-lb-media-remove {
                    position: absolute;
                    top: 4px;
                    left: 4px;
                    z-index: 5;
                    width: 26px;
                    height: 26px;
                    display: flex;
                    align-items: center;
                    justify-content: center;
                    font-size: 18px;
                    line-height: 1;
                    font-weight: bold;
                    color: #fff;
                    background: rgba(179, 45, 46, 0.9);
                    border: none;
                    border-radius: 50%;
                    cursor: pointer;
                    padding: 0 0 2px 0;
                    text-decoration: none;
                }
                .mc-lb-media-remove:hover {
                    background: #b32d2e;
                    color: #fff;
                }
            </style>
            <hr>
            
            <h2><?php echo esc_html__('1. Create New Gallery Folder', 'mc-lightbox'); ?></h2>
            <form method="post" style="margin-bottom: 30px;">
                <?php echo $this->nonce_field('mc_create_folder_action', 'mc-nonce-create-folder'); ?>
                <input type="text" name="mc_folder_name" placeholder="<?php echo esc_attr__('e.g. summer-2026', 'mc-lightbox'); ?>" required style="width: 300px;">
                <input type="submit" name="mc_create_folder" class="button button-primary" value="<?php echo esc_attr__('Create Folder', 'mc-lightbox'); ?>">
            </form>




            <h2><?php echo esc_html__('2. Existing Folders & Media Upload', 'mc-lightbox'); ?></h2>
            <?php if (empty($folders)): ?>
                <p><?php echo esc_html__('No gallery folders found yet. Create your first folder above.', 'mc-lightbox'); ?></p>
            <?php else: ?>
                <table class="wp-list-table widefat fixed striped mc-lb-folders-table">
                    <thead>
                        <tr>
                            <th><?php echo esc_html__('Folder Name', 'mc-lightbox'); ?></th>

                            <th><?php echo esc_html__('Media Count', 'mc-lightbox'); ?></th>
                            <th><?php echo esc_html__('Builder Class', 'mc-lightbox'); ?></th>
                            <th><?php echo esc_html__('Actions', 'mc-lightbox'); ?></th>
                        </tr>
                    </thead>
                    <tbody>
                        <?php foreach ($folders as $name):
                            $builder_class = 'mc-galerie-' . $name;
                            $count         = count(self::get_media_files($name));
                        ?>
                            <tr>
                                <td><strong><?php echo esc_html($name); ?></strong></td>
                                <td><?php echo esc_html($count); ?> <?php echo esc_html__('file(s)', 'mc-lightbox'); ?></td>
                                <td>
                                    <code><?php echo esc_html($builder_class); ?></code>
                                    <button type="button" class="button mc-copy-btn" data-mc-copy="<?php echo esc_attr($builder_class); ?>" style="margin-left: 6px;"><?php echo esc_html__('Copy', 'mc-lightbox'); ?></button>
                                </td>
                                <td class="mc-lb-cell-actions">
                                    <a href="<?php echo esc_url(admin_url('admin.php?page=mc-lightbox&folder=' . rawurlencode($name))); ?>" class="button button-secondary"><?php echo esc_html__('Manage Media', 'mc-lightbox'); ?></a>
                                    <form method="post" onsubmit="return confirm('<?php echo esc_js(__('Are you sure you want to delete this folder and all its files?', 'mc-lightbox')); ?>');">
                                        <?php echo $this->nonce_field('mc_delete_folder_action', 'mc-nonce-delete-folder-' . md5($name)); ?>
                                        <input type="hidden" name="mc_delete_folder_name" value="<?php echo esc_attr($name); ?>">
                                        <button type="submit" name="mc_delete_folder" class="button button-link-delete mc-lb-delete-button"><?php echo esc_html__('Delete', 'mc-lightbox'); ?></button>
                                    </form>
                                </td>
                            </tr>
                        <?php endforeach; ?>
                    </tbody>
                </table>
            <?php endif; ?>

            <?php if ('' !== $active_folder && is_dir(MC_LB_UPLOAD_DIR . $active_folder)): ?>
                <hr style="margin-top: 30px;">
                <h2><?php echo esc_html__('Manage media in folder:', 'mc-lightbox'); ?> <em><?php echo esc_html($active_folder); ?></em></h2>

                <form method="post" enctype="multipart/form-data" style="margin-bottom: 20px;">
                    <?php echo $this->nonce_field('mc_upload_action', 'mc-nonce-upload'); ?>
                    <input type="hidden" name="mc_target_folder" value="<?php echo esc_attr($active_folder); ?>">
                    <div class="mc-lb-upload-row">
                        <input type="file" name="mc_images[]" multiple accept="image/*,video/mp4" required>
                        <input type="submit" name="mc_upload_images" class="button button-primary" value="<?php echo esc_attr__('Upload Media', 'mc-lightbox'); ?>">
                    </div>
                    <p class="description"><?php echo esc_html__('Allowed: JPG, JPEG, PNG, WEBP, GIF and MP4 videos.', 'mc-lightbox'); ?></p>
                </form>

                <?php
                $current_media = self::get_media_files($active_folder);
                if ($current_media):
                    $alt_meta = self::read_metadata($active_folder);
                    ?>
                    <?php foreach ($current_media as $media_index => $media_item):
                        $delete_file_name = basename($media_item);
                        ?>
                        <form id="mc-delete-media-<?php echo esc_attr($media_index); ?>" method="post" style="display:none;">
                            <?php echo $this->nonce_field('mc_delete_media_action', 'mc-nonce-delete-media-' . $media_index); ?>
                            <input type="hidden" name="mc_delete_folder" value="<?php echo esc_attr($active_folder); ?>">
                            <input type="hidden" name="mc_delete_file" value="<?php echo esc_attr($delete_file_name); ?>">
                            <input type="hidden" name="mc_delete_media" value="1">
                        </form>
                    <?php endforeach; ?>
                    <form method="post">
                        <?php echo $this->nonce_field('mc_save_alt_action', 'mc-nonce-save-alt'); ?>
                        <input type="hidden" name="mc_alt_folder" value="<?php echo esc_attr($active_folder); ?>">
                        <div style="display: flex; flex-wrap: wrap; gap: 15px; margin-top: 20px;">
                            <?php foreach ($current_media as $media_index => $media):
                                $file_name = basename($media);
                                $media_url = self::get_media_url($active_folder, $file_name);
                                $alt_value = isset($alt_meta[$file_name]) && is_string($alt_meta[$file_name]) ? $alt_meta[$file_name] : '';
                                $is_video  = self::is_video($file_name);
                                $extension = strtoupper(pathinfo($file_name, PATHINFO_EXTENSION));
                                ?>
                                <div style="width: 180px; background: #fff; border: 1px solid #ccc; border-radius: 4px; padding: 8px; box-sizing: border-box;">
                                    <div class="mc-thumb-preview mc-lb-media-item" data-mc-preview="<?php echo esc_url($media_url); ?>" data-mc-type="<?php echo $is_video ? 'video' : 'image'; ?>" style="position: relative; width: 100%; height: 120px; overflow: hidden; background: #f0f0f1; cursor: zoom-in;">
                                        <?php if ($is_video): ?>
                                            <span class="mc-lb-video-badge"><?php echo esc_html($extension); ?></span>
                                            <video src="<?php echo esc_url($media_url); ?>" muted preload="metadata" playsinline></video>
                                        <?php else: ?>
                                            <img src="<?php echo esc_url($media_url); ?>" loading="lazy" decoding="async" style="width: 100%; height: 100%; object-fit: cover; pointer-events: none;">
                                        <?php endif; ?>
                                        <button type="submit" form="mc-delete-media-<?php echo esc_attr($media_index); ?>" class="mc-lb-media-remove" title="<?php echo esc_attr__('Delete file', 'mc-lightbox'); ?>" onclick="return confirm('<?php echo esc_js(__('Are you sure you want to delete this file?', 'mc-lightbox')); ?>');">&times;</button>
                                    </div>
                                    <p style="margin: 6px 0; font-size: 11px; color: #50575e; word-break: break-all;"><?php echo esc_html($file_name); ?></p>
                                    <input type="text" name="mc_alt[<?php echo esc_attr($file_name); ?>]" value="<?php echo esc_attr($alt_value); ?>" placeholder="<?php echo $is_video ? esc_attr__('Title / caption', 'mc-lightbox') : esc_attr__('Alt text', 'mc-lightbox'); ?>" style="width: 100%; box-sizing: border-box;">
                                </div>
                            <?php endforeach; ?>
                        </div>
                        <p style="margin-top: 15px;">
                            <input type="submit" name="mc_save_alt_texts" class="button button-primary" value="<?php echo esc_attr__('Save Alt Texts', 'mc-lightbox'); ?>">
                        </p>
                    </form>
                <?php else:
                    echo '<p>' . esc_html__('No media in this folder yet.', 'mc-lightbox') . '</p>';
                endif;
                ?>
            <?php endif; ?>
        </div>

        <div id="mc-admin-preview" style="display: none; position: fixed; inset: 0; background: rgba(0,0,0,0.85); z-index: 100000; align-items: center; justify-content: center; cursor: zoom-out;">
            <img id="mc-admin-preview-img" alt="" style="max-width: 90vw; max-height: 90vh; box-shadow: 0 0 30px rgba(0,0,0,0.5); display: none;">
            <video id="mc-admin-preview-video" controls playsinline preload="metadata" style="max-width: 90vw; max-height: 90vh; box-shadow: 0 0 30px rgba(0,0,0,0.5); display: none; background: #000;"></video>
        </div>
        <script>
        (function () {
            var overlay = document.getElementById('mc-admin-preview');
            var previewImg = document.getElementById('mc-admin-preview-img');
            var previewVideo = document.getElementById('mc-admin-preview-video');

            function closePreview() {
                overlay.style.display = 'none';
                previewImg.style.display = 'none';
                previewImg.removeAttribute('src');
                try { previewVideo.pause(); } catch (err) {}
                previewVideo.style.display = 'none';
                previewVideo.removeAttribute('src');
                previewVideo.load();
            }

            document.addEventListener('click', function (e) {
                var thumb = e.target.closest('[data-mc-preview]');
                if (!thumb) return;
                if (e.target.closest('.mc-lb-media-remove')) return;
                var url = thumb.getAttribute('data-mc-preview');
                if (!url) return;
                var type = thumb.getAttribute('data-mc-type');
                if (type === 'video') {
                    previewVideo.src = url;
                    previewVideo.style.display = 'block';
                    previewVideo.play().catch(function () {});
                } else {
                    previewImg.src = url;
                    previewImg.style.display = 'block';
                }
                overlay.style.display = 'flex';
            });

            overlay.addEventListener('click', function (e) {
                if (e.target === previewVideo) return;
                closePreview();
            });

            document.addEventListener('keydown', function (e) {
                if (e.key === 'Escape' && overlay.style.display === 'flex') {
                    closePreview();
                }
            });
        })();
        </script>
        <script>
        (function () {
            function fallbackCopy(text) {
                var tmp = document.createElement('textarea');
                tmp.value = text;
                tmp.setAttribute('readonly', '');
                tmp.style.position = 'absolute';
                tmp.style.left = '-9999px';
                document.body.appendChild(tmp);
                tmp.select();
                try {
                    document.execCommand('copy');
                } catch (err) {}
                document.body.removeChild(tmp);
            }
            document.addEventListener('click', function (e) {
                var btn = e.target.closest('[data-mc-copy]');
                if (!btn) return;
                var text = btn.getAttribute('data-mc-copy');
                if (!text) return;
                var original = btn.getAttribute('data-mc-original') || btn.textContent;
                if (!btn.hasAttribute('data-mc-original')) {
                    btn.setAttribute('data-mc-original', original);
                }
                function done() {
                    btn.textContent = '<?php echo esc_js(__('Copied!', 'mc-lightbox')); ?>';
                    clearTimeout(btn.mcCopyTimer);
                    btn.mcCopyTimer = setTimeout(function () { btn.textContent = original; }, 1500);
                }
                if (navigator.clipboard && navigator.clipboard.writeText) {
                    navigator.clipboard.writeText(text).then(done, function () {
                        fallbackCopy(text);
                        done();
                    });
                } else {
                    fallbackCopy(text);
                    done();
                }
            });
        })();
        </script>
        <?php
    }
}

new MC_Lightbox_Admin();
