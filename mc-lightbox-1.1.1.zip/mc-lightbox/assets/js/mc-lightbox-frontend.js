(function () {
    let initialized = false;

    function init() {
        if (initialized) return;
        initialized = true;

        const data = window.mcLightboxData || {};
        const strings = data.i18n || {};
        const labels = {
            gallery: strings.gallery || 'Gallery',
            close: strings.close || 'Close',
            previous: strings.previous || 'Previous item',
            next: strings.next || 'Next item'
        };

        let media = [];
        let currentIndex = 0;
        let touchStartX = 0;
        let touchStartY = 0;
        let touchEndX = 0;
        let touchEndY = 0;
        let touchTracking = false;
        let openToken = 0;
        let requestController = null;
        let lastFocusedElement = null;

        const overlay = document.createElement('div');
        overlay.className = 'mc-lb-overlay';
        overlay.setAttribute('role', 'dialog');
        overlay.setAttribute('aria-modal', 'true');
        overlay.setAttribute('aria-label', labels.gallery);
        overlay.innerHTML = `
            <button type="button" class="mc-lb-close"><svg class="mc-lb-close-icon" viewBox="0 0 24 24" width="24" height="24" fill="none" aria-hidden="true"><path d="M6 6L18 18M18 6L6 18" stroke="currentColor" stroke-width="2.5" stroke-linecap="round"/></svg></button>
            <button type="button" class="mc-lb-prev">&#10094;</button>
            <div class="mc-lb-container">
                <div class="mc-lb-spinner" aria-hidden="true"></div>
                <img class="mc-lb-image" alt="" style="display:none;">
                <video class="mc-lb-video" controls playsinline preload="metadata" style="display:none;"></video>
            </div>
            <button type="button" class="mc-lb-next">&#10095;</button>
            <div class="mc-lb-counter" aria-live="polite" aria-atomic="true"></div>
        `;
        document.body.appendChild(overlay);

        const imgEl = overlay.querySelector('.mc-lb-image');
        const videoEl = overlay.querySelector('.mc-lb-video');
        const spinner = overlay.querySelector('.mc-lb-spinner');
        const counter = overlay.querySelector('.mc-lb-counter');
        const closeBtn = overlay.querySelector('.mc-lb-close');
        const prevBtn = overlay.querySelector('.mc-lb-prev');
        const nextBtn = overlay.querySelector('.mc-lb-next');

        closeBtn.setAttribute('aria-label', labels.close);
        prevBtn.setAttribute('aria-label', labels.previous);
        nextBtn.setAttribute('aria-label', labels.next);

        const isTouchDevice = ('ontouchstart' in window) ||
            (navigator.maxTouchPoints > 0);

        const TRIGGER_PREFIX = 'mc-galerie-';

        function folderFromClassList(classList) {
            if (!classList) return '';
            for (let i = 0; i < classList.length; i++) {
                const cls = classList[i];
                if (cls.indexOf(TRIGGER_PREFIX) === 0 && cls.length > TRIGGER_PREFIX.length) {
                    return cls.substring(TRIGGER_PREFIX.length);
                }
            }
            return '';
        }

        function findTrigger(el) {
            let node = el;
            while (node && node !== document.body && node.nodeType === 1) {
                if (node.classList) {
                    if (node.hasAttribute('data-mc-folder')) {
                        const folder = node.getAttribute('data-mc-folder');
                        if (folder) {
                            return { element: node, folder: folder };
                        }
                    }
                    const folder = folderFromClassList(node.classList);
                    if (folder) {
                        return { element: node, folder: folder };
                    }
                }
                node = node.parentElement;
            }
            return null;
        }

        function initTriggers() {
            const candidates = document.querySelectorAll('[data-mc-folder], [class*="mc-galerie-"]');
            candidates.forEach((el) => {
                if (el.hasAttribute('data-mc-folder') || folderFromClassList(el.classList)) {
                    el.style.cursor = 'pointer';
                }
            });
        }

        initTriggers();
        window.addEventListener('load', initTriggers);

        document.addEventListener('click', (e) => {
            const trigger = findTrigger(e.target);
            if (!trigger || !trigger.folder) return;

            e.preventDefault();
            openLightbox(trigger.folder);
        });

        let scrollLockY = 0;
        let scrollLocked = false;
        let savedBodyStyles = null;

        function lockScroll() {
            if (scrollLocked) return;
            scrollLocked = true;

            const body = document.body;
            scrollLockY = window.pageYOffset || document.documentElement.scrollTop || 0;
            savedBodyStyles = {
                position: body.style.position,
                top: body.style.top,
                left: body.style.left,
                right: body.style.right,
                width: body.style.width,
                overflow: body.style.overflow,
                paddingRight: body.style.paddingRight
            };

            if (isTouchDevice) {
                body.style.position = 'fixed';
                body.style.top = '-' + scrollLockY + 'px';
                body.style.left = '0';
                body.style.right = '0';
                body.style.width = '100%';
            } else {
                const scrollbarWidth = window.innerWidth - document.documentElement.clientWidth;
                if (scrollbarWidth > 0) {
                    const padding = parseFloat(window.getComputedStyle(body).paddingRight) || 0;
                    body.style.paddingRight = (padding + scrollbarWidth) + 'px';
                }
            }

            body.style.overflow = 'hidden';
        }

        function unlockScroll() {
            if (!scrollLocked) return;
            scrollLocked = false;

            if (savedBodyStyles) {
                const body = document.body;
                body.style.position = savedBodyStyles.position;
                body.style.top = savedBodyStyles.top;
                body.style.left = savedBodyStyles.left;
                body.style.right = savedBodyStyles.right;
                body.style.width = savedBodyStyles.width;
                body.style.overflow = savedBodyStyles.overflow;
                body.style.paddingRight = savedBodyStyles.paddingRight;
                savedBodyStyles = null;
            }

            window.scrollTo(0, scrollLockY);
        }

        function normalizeMedia(json) {
            if (!Array.isArray(json)) return [];
            return json.map((item) => {
                if (typeof item === 'string') {
                    const isVideo = /\.(mp4|webm|ogg|mov|m4v)$/i.test(item);
                    return { url: item, type: isVideo ? 'video' : 'image', alt: '' };
                }
                if (item && typeof item === 'object' && typeof item.url === 'string') {
                    const type = item.type === 'video' || item.type === 'image'
                        ? item.type
                        : (/\.(mp4|webm|ogg|mov|m4v)$/i.test(item.url) ? 'video' : 'image');
                    return {
                        url: item.url,
                        type: type,
                        alt: typeof item.alt === 'string' ? item.alt : ''
                    };
                }
                return null;
            }).filter(Boolean);
        }

        function stopMedia() {
            imgEl.onload = null;
            imgEl.onerror = null;
            imgEl.removeAttribute('src');
            imgEl.alt = '';
            imgEl.style.display = 'none';

            videoEl.onloadeddata = null;
            videoEl.onerror = null;
            try {
                videoEl.pause();
            } catch (err) {}
            videoEl.removeAttribute('src');
            videoEl.removeAttribute('aria-label');
            videoEl.removeAttribute('title');
            videoEl.load();
            videoEl.style.display = 'none';
        }

        function resetUi() {
            counter.textContent = '';
            counter.style.display = 'none';
            prevBtn.style.visibility = 'hidden';
            nextBtn.style.visibility = 'hidden';
            spinner.style.display = 'none';
        }

        function focusElement(el) {
            if (!el || typeof el.focus !== 'function') return;
            try {
                el.focus({ preventScroll: true });
            } catch (err) {
                el.focus();
            }
        }

        function getFocusableElements() {
            return Array.from(overlay.querySelectorAll('button, video[controls]')).filter((el) => {
                if (el.disabled) return false;
                const style = window.getComputedStyle(el);
                return style.display !== 'none' && style.visibility !== 'hidden';
            });
        }

        function trapFocus(e) {
            const focusable = getFocusableElements();
            if (!focusable.length) return;

            const first = focusable[0];
            const last = focusable[focusable.length - 1];

            if (!overlay.contains(document.activeElement)) {
                e.preventDefault();
                focusElement(first);
                return;
            }

            if (e.shiftKey && document.activeElement === first) {
                e.preventDefault();
                focusElement(last);
            } else if (!e.shiftKey && document.activeElement === last) {
                e.preventDefault();
                focusElement(first);
            }
        }

        async function openLightbox(folder) {
            if (!folder) return;

            const token = ++openToken;
            if (requestController) {
                requestController.abort();
            }
            requestController = typeof AbortController !== 'undefined' ? new AbortController() : null;

            resetUi();
            stopMedia();
            spinner.style.display = 'block';

            if (!overlay.classList.contains('mc-lb-active')) {
                lastFocusedElement = document.activeElement;
            }

            lockScroll();
            overlay.classList.add('mc-lb-active');
            focusElement(closeBtn);

            try {
                let baseUrl = (data && data.restUrl) ? data.restUrl : '/wp-json/mc-lightbox/v1/gallery/';
                if (baseUrl.slice(-1) !== '/') {
                    baseUrl += '/';
                }

                const response = await fetch(`${baseUrl}${encodeURIComponent(folder)}`, requestController
                    ? { signal: requestController.signal }
                    : {});

                if (token !== openToken || !overlay.classList.contains('mc-lb-active')) return;
                if (response.ok === false) {
                    throw new Error('HTTP ' + response.status);
                }

                const json = await response.json();

                if (token !== openToken || !overlay.classList.contains('mc-lb-active')) return;

                media = normalizeMedia(json);

                if (media.length === 0) {
                    closeLightbox();
                    return;
                }

                currentIndex = 0;
                showMedia(currentIndex);
            } catch (err) {
                if (err && err.name === 'AbortError') return;
                if (token !== openToken) return;
                closeLightbox();
            }
        }

        function updateNav() {
            const hasMultiple = media.length > 1;
            prevBtn.style.visibility = (hasMultiple && currentIndex > 0) ? 'visible' : 'hidden';
            nextBtn.style.visibility = (hasMultiple && currentIndex < media.length - 1) ? 'visible' : 'hidden';
            counter.style.display = hasMultiple ? 'block' : 'none';
        }

        function showMedia(index) {
            if (index < 0 || index >= media.length) return;

            const item = media[index];
            const altText = item.alt || '';

            stopMedia();
            spinner.style.display = 'block';

            counter.textContent = `${index + 1} / ${media.length}`;
            updateNav();

            if (item.type === 'video') {
                if (altText) {
                    videoEl.setAttribute('aria-label', altText);
                    videoEl.setAttribute('title', altText);
                }
                videoEl.src = item.url;
                videoEl.style.display = 'block';
                videoEl.onloadeddata = () => {
                    spinner.style.display = 'none';
                };
                videoEl.onerror = () => {
                    spinner.style.display = 'none';
                };
            } else {
                imgEl.alt = altText;
                imgEl.src = item.url;
                imgEl.onload = () => {
                    spinner.style.display = 'none';
                    imgEl.style.display = 'block';
                };
                imgEl.onerror = () => {
                    spinner.style.display = 'none';
                };
            }
        }

        function closeLightbox() {
            ++openToken;
            if (requestController) {
                requestController.abort();
                requestController = null;
            }

            stopMedia();
            resetUi();
            overlay.classList.remove('mc-lb-active');
            media = [];
            currentIndex = 0;
            unlockScroll();

            const previousFocus = lastFocusedElement;
            lastFocusedElement = null;
            if (previousFocus && previousFocus !== document.body && document.contains(previousFocus)) {
                focusElement(previousFocus);
            }

            // Never leave focus on a button inside the now-hidden overlay.
            if (document.activeElement && overlay.contains(document.activeElement)) {
                document.activeElement.blur();
            }
        }

        function prevMedia() {
            if (currentIndex > 0) {
                currentIndex--;
                showMedia(currentIndex);
            }
        }

        function nextMedia() {
            if (currentIndex < media.length - 1) {
                currentIndex++;
                showMedia(currentIndex);
            }
        }

        closeBtn.addEventListener('click', closeLightbox);
        prevBtn.addEventListener('click', prevMedia);
        nextBtn.addEventListener('click', nextMedia);

        overlay.addEventListener('click', (e) => {
            if (e.target === overlay || e.target.classList.contains('mc-lb-container')) {
                closeLightbox();
            }
        });

        document.addEventListener('keydown', (e) => {
            if (!overlay.classList.contains('mc-lb-active')) return;

            if (e.key === 'Tab') {
                trapFocus(e);
                return;
            }

            if (e.key === 'Escape') {
                closeLightbox();
                return;
            }

            if (e.target === videoEl || videoEl.contains(e.target)) return;

            if (e.key === 'ArrowLeft') {
                e.preventDefault();
                prevMedia();
            }
            if (e.key === 'ArrowRight') {
                e.preventDefault();
                nextMedia();
            }
        });

        if (isTouchDevice) {
            overlay.addEventListener('touchstart', (e) => {
                if (e.target === videoEl || videoEl.contains(e.target)) {
                    touchTracking = false;
                    return;
                }
                if (e.target.closest && e.target.closest('button')) {
                    touchTracking = false;
                    return;
                }

                touchTracking = true;
                touchStartX = e.changedTouches[0].screenX;
                touchStartY = e.changedTouches[0].screenY;
            }, { passive: true });

            overlay.addEventListener('touchend', (e) => {
                if (!touchTracking) return;
                touchTracking = false;

                touchEndX = e.changedTouches[0].screenX;
                touchEndY = e.changedTouches[0].screenY;
                handleSwipe();
            }, { passive: true });

            overlay.addEventListener('touchcancel', () => {
                touchTracking = false;
            }, { passive: true });
        }

        function handleSwipe() {
            const diffX = touchEndX - touchStartX;
            const diffY = touchEndY - touchStartY;

            if (Math.abs(diffX) > Math.abs(diffY)) {
                if (Math.abs(diffX) > 40) {
                    if (diffX < 0) nextMedia();
                    else prevMedia();
                }
            } else if (diffY > 60) {
                closeLightbox();
            }
        }
    }

    if (document.readyState === 'loading') {
        document.addEventListener('DOMContentLoaded', init);
    } else {
        init();
    }
})();
