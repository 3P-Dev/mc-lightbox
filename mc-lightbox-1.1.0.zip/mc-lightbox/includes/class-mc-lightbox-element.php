<?php
if (!defined('ABSPATH')) {
    exit;
}

class MC_Lightbox_Element {

    public function __construct() {
        add_action('init', [$this, 'register_mosaik_element']);
    }

    private function get_available_folders() {
        $folders = array_filter(glob(MC_LB_UPLOAD_DIR . '*'), 'is_dir');
        $options = ['' => '-- Select folder --'];

        if (!empty($folders)) {
            foreach ($folders as $folder_path) {
                $folder_name = basename($folder_path);
                $options[$folder_name] = $folder_name;
            }
        }

        return $options;
    }

    public function register_mosaik_element() {
        if (!function_exists('mosaik_register_element') && !class_exists('Mosaik_Builder')) {
            return;
        }

        $folders = $this->get_available_folders();

        $element_args = [
            'name'        => 'mc_lightbox',
            'title'       => 'MC-Lightbox',
            'icon'        => 'dashicons-format-gallery',
                        'category'    => 'media',
            'controls'    => [
                'trigger_image' => [
                    'type'        => 'image',
                    'label'       => 'Trigger image (Cover)',
                    'description' => 'Select the image that appears as a preview on the page.',
                    'default'     => '',
                ],
                'gallery_folder' => [
                    'type'        => 'select',
                    'label'       => 'Gallery folder',
                    'description' => 'Select a folder from the MC-Lightbox management.',
                    'options'     => $folders,
                    'default'     => '',
                ],
                'image_alt' => [
                    'type'        => 'text',
                    'label'       => 'Alt text (SEO)',
                    'default'     => 'Gallery preview',
                ]
            ],
            'render_callback' => [$this, 'render_element_html']
        ];

                        if (function_exists('mosaik_register_element')) {
            mosaik_register_element($element_args);
        }
    }

    public function render_element_html($attributes) {
        $image_id = !empty($attributes['trigger_image']) ? $attributes['trigger_image'] : '';
                $folder   = !empty($attributes['gallery_folder']) ? sanitize_title($attributes['gallery_folder']) : '';
        $alt      = !empty($attributes['image_alt']) ? $attributes['image_alt'] : '';

        if (empty($folder)) {
            return '<p style="padding:15px; background:#fff3cd; color:#856404; border:1px solid #ffeeba;">Please select a gallery folder in the MC-Lightbox element.</p>';
        }

        $img_src = '';
        if (is_numeric($image_id)) {
            $img_data = wp_get_attachment_image_src($image_id, 'full');
            if ($img_data) {
                $img_src = $img_data[0];
            }
        } elseif (is_string($image_id)) {
            $img_src = esc_url($image_id);
        }

        $image_exts = defined('MC_LB_IMAGE_EXTENSIONS') ? MC_LB_IMAGE_EXTENSIONS : 'jpg,jpeg,png,webp,gif';

        $alt_from_meta = '';
        if (empty($img_src) || !empty($folder)) {
            $images = glob(MC_LB_UPLOAD_DIR . $folder . '/*.{' . $image_exts . '}', GLOB_BRACE);

            if (empty($img_src) && !empty($images)) {
                natsort($images);
                $images = array_values($images);
                $img_src = MC_LB_UPLOAD_URL . $folder . '/' . basename($images[0]);
            }

            if (!empty($images)) {
                natsort($images);
                $images = array_values($images);
                $first_file = basename($images[0]);
                if (class_exists('MC_Lightbox_Admin') && method_exists('MC_Lightbox_Admin', 'get_alt_text')) {
                    $alt_from_meta = MC_Lightbox_Admin::get_alt_text($folder, $first_file);
                }
            }
        }

        if ($alt_from_meta !== '') {
            $alt = $alt_from_meta;
        }

        if (empty($img_src)) {
            return '<p style="padding:15px; background:#f8d7da; color:#721c24; border:1px solid #f5c6cb;">No preview image found and the folder is empty.</p>';
        }

        $builder_class = 'mc-galerie-' . $folder;

        ob_start();
        ?>
        <div class="<?php echo esc_attr($builder_class); ?> mc-lightbox-trigger-wrap" data-mc-folder="<?php echo esc_attr($folder); ?>" style="cursor: pointer; display: inline-block; max-width: 100%;">
            <a href="#" style="display: block; text-decoration: none;">
                <img src="<?php echo esc_url($img_src); ?>" alt="<?php echo esc_attr($alt); ?>" style="max-width: 100%; height: auto; display: block;">
            </a>
        </div>
        <?php
        return ob_get_clean();
    }
}

new MC_Lightbox_Element();