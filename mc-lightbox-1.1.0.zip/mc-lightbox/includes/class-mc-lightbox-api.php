<?php
if (!defined('ABSPATH')) {
    exit;
}

class MC_Lightbox_API {

    public function __construct() {
        add_action('rest_api_init', [$this, 'register_routes']);
    }

    public function register_routes() {
        register_rest_route('mc-lightbox/v1', '/gallery/(?P<folder>[a-zA-Z0-9_-]+)', [
            'methods'  => 'GET',
            'callback' => [$this, 'get_gallery_images'],
            'permission_callback' => '__return_true',
            'args' => [
                'folder' => [
                    'sanitize_callback' => 'sanitize_title',
                ],
            ],
        ]);
    }

    public function get_gallery_images($request) {
        $folder = $request->get_param('folder');

        if (empty($folder)) {
            return new WP_Error('no_folder', 'No folder specified', ['status' => 400]);
        }

        $upload     = wp_upload_dir();
        $base_dir   = $upload['basedir'] . '/mc-galleries/';
        $base_url   = $upload['baseurl'] . '/mc-galleries/';
        $target_dir = realpath($base_dir . $folder);
        $real_base  = realpath($base_dir);

        if ($real_base === false || !$target_dir || strpos($target_dir, $real_base . DIRECTORY_SEPARATOR) !== 0 || !is_dir($target_dir)) {
            return new WP_Error('invalid_folder', 'Invalid or non-existent folder', ['status' => 404]);
        }

        $image_exts = defined('MC_LB_IMAGE_EXTENSIONS') ? MC_LB_IMAGE_EXTENSIONS : 'jpg,jpeg,png,webp,gif';
        $video_exts = defined('MC_LB_VIDEO_EXTENSIONS') ? MC_LB_VIDEO_EXTENSIONS : 'mp4';
        $patterns   = '{' . $image_exts . ',' . $video_exts . '}';
        $files = glob($target_dir . '/*.' . $patterns, GLOB_BRACE);

        if (!$files) {
            return rest_ensure_response([]);
        }

        natsort($files);

        $alt_meta = [];
        $meta_path = $target_dir . DIRECTORY_SEPARATOR . 'metadata.json';
        if (is_file($meta_path)) {
            $meta_raw = file_get_contents($meta_path);
            if ($meta_raw !== false && $meta_raw !== '') {
                $meta_data = json_decode($meta_raw, true);
                if (is_array($meta_data)) {
                    $alt_meta = $meta_data;
                }
            }
        }

        $video_ext_arr = explode(',', $video_exts);
        $media = array_values(array_map(function ($path) use ($folder, $base_url, $video_ext_arr, $alt_meta) {
            $filename = basename($path);
            $ext      = strtolower(pathinfo($filename, PATHINFO_EXTENSION));
            $type     = in_array($ext, $video_ext_arr, true) ? 'video' : 'image';
            $alt      = (isset($alt_meta[$filename]) && is_string($alt_meta[$filename])) ? $alt_meta[$filename] : '';

            return [
                'url'      => $base_url . $folder . '/' . $filename,
                'type'     => $type,
                'filename' => $filename,
                'alt'      => $alt,
            ];
        }, $files));

        return rest_ensure_response($media);
    }
}

new MC_Lightbox_API();

