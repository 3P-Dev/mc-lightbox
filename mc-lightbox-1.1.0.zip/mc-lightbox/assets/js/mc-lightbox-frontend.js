document.addEventListener('DOMContentLoaded', () => {
    let media = [];
    let currentIndex = 0;
    let touchStartX = 0;
    let touchStartY = 0;
    let touchEndX = 0;
    let touchEndY = 0;

    const overlay = document.createElement('div');
    overlay.className = 'mc-lb-overlay';
    overlay.innerHTML = `
        <button class="mc-lb-close" aria-label="Close"><svg class="mc-lb-close-icon" viewBox="0 0 24 24" width="24" height="24" fill="none" aria-hidden="true"><path d="M6 6L18 18M18 6L6 18" stroke="currentColor" stroke-width="2.5" stroke-linecap="round"/></svg></button>
        <button class="mc-lb-prev" aria-label="Previous item">&#10094;</button>
        <div class="mc-lb-container">
            <div class="mc-lb-spinner"></div>
            <img class="mc-lb-image" src="" alt="" style="display:none;">
            <video class="mc-lb-video" controls playsinline preload="metadata" style="display:none;"></video>
        </div>
        <button class="mc-lb-next" aria-label="Next item">&#10095;</button>
        <div class="mc-lb-counter"></div>
    `;
    document.body.appendChild(overlay);

    const imgEl = overlay.querySelector('.mc-lb-image');
    const videoEl = overlay.querySelector('.mc-lb-video');
    const spinner = overlay.querySelector('.mc-lb-spinner');
    const counter = overlay.querySelector('.mc-lb-counter');
    const closeBtn = overlay.querySelector('.mc-lb-close');
    const prevBtn = overlay.querySelector('.mc-lb-prev');
    const nextBtn = overlay.querySelector('.mc-lb-next');

    const isTouchDevice = ('ontouchstart' in window) ||
        (navigator.maxTouchPoints > 0) ||
        (navigator.msMaxTouchPoints > 0);

    const TRIGGER_PREFIX = 'mc-galerie-';

    function folderFromClassList(classList) {
        if (!classList) return '';
        for (let i = 0; i < classList.length; i++) {
            const cls = classList[i];
            if (cls.indexOf(TRIGGER_PREFIX) === 0 && cls.length > TRIGGER_PREFIX.length) {
                return cls.substring(TRIGGER_PREFIX.length);
            }
        }
        return '';
    }

    function findTrigger(el) {
        let node = el;
        while (node && node !== document.body && node.nodeType === 1) {
            if (node.classList) {
                if (node.hasAttribute('data-mc-folder')) {
                    return { element: node, folder: node.getAttribute('data-mc-folder') };
                }
                const folder = folderFromClassList(node.classList);
                if (folder) {
                    return { element: node, folder: folder };
                }
            }
            node = node.parentElement;
        }
        return null;
    }

    function initTriggers() {
        const all = document.querySelectorAll('*');
        all.forEach((el) => {
            if (!el.classList) return;
            if (el.hasAttribute('data-mc-folder') || folderFromClassList(el.classList)) {
                el.style.cursor = 'pointer';
            }
        });
    }

    initTriggers();
    window.addEventListener('load', initTriggers);

    document.addEventListener('click', (e) => {
        const trigger = findTrigger(e.target);
        if (!trigger || !trigger.folder) return;

        e.preventDefault();
        openLightbox(trigger.folder);
    });

    let scrollLockY = 0;
    let scrollLocked = false;

    function lockScroll() {
        if (!isTouchDevice || scrollLocked) return;
        scrollLocked = true;
        scrollLockY = window.pageYOffset || document.documentElement.scrollTop || 0;
        document.body.style.position = 'fixed';
        document.body.style.top = '-' + scrollLockY + 'px';
        document.body.style.left = '0';
        document.body.style.right = '0';
        document.body.style.width = '100%';
        document.body.style.overflow = 'hidden';
    }

    function unlockScroll() {
        if (!isTouchDevice || !scrollLocked) return;
        scrollLocked = false;
        document.body.style.position = '';
        document.body.style.top = '';
        document.body.style.left = '';
        document.body.style.right = '';
        document.body.style.width = '';
        document.body.style.overflow = '';
        window.scrollTo(0, scrollLockY);
    }

    function normalizeMedia(json) {
        if (!Array.isArray(json)) return [];
        return json.map((item) => {
            if (typeof item === 'string') {
                const isVideo = /\.(mp4|webm|ogg|mov|m4v)$/i.test(item);
                return { url: item, type: isVideo ? 'video' : 'image', alt: '' };
            }
            if (item && typeof item === 'object' && item.url) {
                const type = item.type
                    ? item.type
                    : (/\.(mp4|webm|ogg|mov|m4v)$/i.test(item.url) ? 'video' : 'image');
                return { url: item.url, type: type, alt: item.alt || '' };
            }
            return null;
        }).filter(Boolean);
    }

    function stopMedia() {
        imgEl.onload = null;
        imgEl.onerror = null;
        imgEl.src = '';
        imgEl.alt = '';
        imgEl.style.display = 'none';

        try {
            videoEl.pause();
        } catch (err) {}
        videoEl.removeAttribute('src');
        videoEl.removeAttribute('aria-label');
        videoEl.removeAttribute('title');
        videoEl.load();
        videoEl.style.display = 'none';
    }

    async function openLightbox(folder) {
        spinner.style.display = 'block';
        imgEl.style.display = 'none';
        videoEl.style.display = 'none';
        lockScroll();
        overlay.classList.add('mc-lb-active');

        try {
            const baseUrl = (window.mcLightboxData && window.mcLightboxData.restUrl)
                ? window.mcLightboxData.restUrl
                : '/wp-json/mc-lightbox/v1/gallery/';
            const response = await fetch(`${baseUrl}${encodeURIComponent(folder)}`);
            const json = await response.json();

            media = normalizeMedia(json);

            if (media.length === 0) {
                closeLightbox();
                return;
            }

            currentIndex = 0;
            showMedia(currentIndex);
        } catch (err) {
            closeLightbox();
        }
    }

    function updateNav() {
        const hasMultiple = media.length > 1;
        prevBtn.style.visibility = (hasMultiple && currentIndex > 0) ? 'visible' : 'hidden';
        nextBtn.style.visibility = (hasMultiple && currentIndex < media.length - 1) ? 'visible' : 'hidden';
        counter.style.display = hasMultiple ? 'block' : 'none';
    }

    function showMedia(index) {
        if (index < 0 || index >= media.length) return;

        const item = media[index];
        const altText = item.alt || '';

        stopMedia();
        spinner.style.display = 'block';

        counter.textContent = `${index + 1} / ${media.length}`;
        updateNav();

        if (item.type === 'video') {
            if (altText) {
                videoEl.setAttribute('aria-label', altText);
                videoEl.setAttribute('title', altText);
            }
            videoEl.src = item.url;
            videoEl.style.display = 'block';
            videoEl.onloadeddata = () => {
                spinner.style.display = 'none';
            };
            videoEl.onerror = () => {
                spinner.style.display = 'none';
            };
        } else {
            imgEl.alt = altText;
            imgEl.src = item.url;
            imgEl.onload = () => {
                spinner.style.display = 'none';
                imgEl.style.display = 'block';
            };
            imgEl.onerror = () => {
                spinner.style.display = 'none';
            };
        }
    }

    function closeLightbox() {
        stopMedia();
        overlay.classList.remove('mc-lb-active');
        media = [];
        unlockScroll();
    }

    function prevMedia() {
        if (currentIndex > 0) {
            currentIndex--;
            showMedia(currentIndex);
        }
    }

    function nextMedia() {
        if (currentIndex < media.length - 1) {
            currentIndex++;
            showMedia(currentIndex);
        }
    }

    closeBtn.addEventListener('click', closeLightbox);
    prevBtn.addEventListener('click', prevMedia);
    nextBtn.addEventListener('click', nextMedia);

    overlay.addEventListener('click', (e) => {
        if (e.target === overlay || e.target.classList.contains('mc-lb-container')) {
            closeLightbox();
        }
    });

    document.addEventListener('keydown', (e) => {
        if (!overlay.classList.contains('mc-lb-active')) return;
        if (e.key === 'Escape') {
            closeLightbox();
            return;
        }
        if (e.target === videoEl) return;
        if (e.key === 'ArrowLeft') prevMedia();
        if (e.key === 'ArrowRight') nextMedia();
    });

    if (isTouchDevice) {
        overlay.addEventListener('touchstart', (e) => {
            touchStartX = e.changedTouches[0].screenX;
            touchStartY = e.changedTouches[0].screenY;
        }, { passive: true });

        overlay.addEventListener('touchend', (e) => {
            touchEndX = e.changedTouches[0].screenX;
            touchEndY = e.changedTouches[0].screenY;
            handleSwipe();
        }, { passive: true });
    }

    function handleSwipe() {
        const diffX = touchEndX - touchStartX;
        const diffY = touchEndY - touchStartY;

        if (Math.abs(diffX) > Math.abs(diffY)) {
            if (Math.abs(diffX) > 40) {
                if (diffX < 0) nextMedia();
                else prevMedia();
            }
        } else {
            if (diffY > 60) closeLightbox();
        }
    }
});
